import { Box, Button } from '@mantine/core';
import logoUrl from '../../assets/icons/logo.png'
import { useStyles } from './style';
import SearchApplicationModal from './SearchApplicationModal';
import {Link} from 'react-router-dom';

const Header = ({}) => {
  const classes = useStyles();
 
    


    return (
      <>
      <Box>
        <Box>
          <Link to={'/'}><img className={classes.logo} src={logoUrl} alt='logo'/></Link>  

       {/* Search Application By ID modal  */}
      <SearchApplicationModal/>  
        </Box>
        </Box>
        </>
    );
}


export default Header;