
import { makeStyles } from '@material-ui/styles';

export const useStyles = makeStyles({
    modalFooter: {
        marginTop: 30,
        display: 'flex',
        justifyContent: 'space-evenly',
        'button': {
            minWidth: 200,
            // [theme.fn.smallerThan(576)]: {
            //     minWidth: 150,
              
            // },
        },
    }
  });
// export const useStyles = createStyles(theme => ({
//     modalFooter: {
//         marginTop: 30,
//         display: 'flex',
//         justifyContent: 'space-evenly',
//         'button': {
//             minWidth: 200,
//             // [theme.fn.smallerThan(576)]: {
//             //     minWidth: 150,
              
//             // },
//         },
//     }
// }
// ))