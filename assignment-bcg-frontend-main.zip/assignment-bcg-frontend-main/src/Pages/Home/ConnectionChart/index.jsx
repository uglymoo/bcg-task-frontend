import { Box, Group, Radio, Button } from '@mantine/core';
import { useStyles } from './style';

import { useEffect, useState } from 'react';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { backendBaseURL, getHeader } from '../../../Utils/const';
import { MonthPickerInput } from '@mantine/dates';
function ConnectionChart() {

    const classes = useStyles();
    const [dashboardData, setDashboardData] = useState({ datasets: [], labels: ['January', 'February', 'March', 'April', 'May'] });
    let firstDate = new Date(2021, 5, 28);
    firstDate.setDate(firstDate.getDate() - 140)
    const [dateRange, setDateRange] = useState([firstDate, new Date(2021, 5, 28)]);
    const [status, setStatus] = useState('Approved');
    const [error, setError] = useState('');
    ChartJS.register(
        CategoryScale,
        LinearScale,
        BarElement,
        Title,
        Tooltip,
        Legend
    );
    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Monthly Connection Request',
            },
        },
    };
    const monthDiff = (d1, d2) => {
        let months;
        months = (d2.getFullYear() - d1.getFullYear()) * 12;
        months -= d1.getMonth();
        months += d2.getMonth();
        return months <= 0 ? 0 : months;
    }
    function getMonthsBetweenDates(startDate, endDate) {

        let months = [];

        let currentDate = new Date(startDate);
        while (currentDate <= endDate) {

            let year = currentDate.getFullYear();
            let month = currentDate.getMonth() + 1; // Month is 0-indexed, so add 1
            let monthName = currentDate.toLocaleDateString('en-US', { month: 'long' }); // Get m

            if (!months.some(m => m.year === year && m.month === month)) {
                months.push(`${monthName}, ${year}`);
            }

            currentDate.setMonth(currentDate.getMonth() + 1);
        }

        return months;
    }
    async function fetchDashboardData() {


        console.log('status is', status);
        console.log('dateRange is', dateRange);
        let body = {}
        if (!status) return setError('Please select Connection Status');
        body.status = status;
        if (!dateRange || !dateRange[0] || !dateRange[0])
            return setError('Please select Date Range');

        const startDate = new Date(dateRange[0]);
        const endDate = new Date(dateRange[1]);
        const monthDifference = monthDiff(startDate, endDate);
        console.log('monthDifference is ', monthDifference);
        if (monthDifference > 12) return setError('Date range must be less than a year');
        body.startMonth = startDate.getMonth();
        body.startYear = startDate.getFullYear()

        body.endMonth = endDate.getMonth();
        body.endYear = endDate.getFullYear()
        setError('');
        console.log('body is', body);
        console.log(getMonthsBetweenDates(startDate, endDate));
        const response = await fetch(`${backendBaseURL}/user/dashboard/`, {
            method: 'POST',
            body: JSON.stringify(body),
            headers: getHeader()
        });
        console.log(response)
        if (response.ok) {
            let dashboardData = await response.json();
            console.log('startDate is ', startDate);
            console.log('endDate is ', endDate);
            console.log('debugger is ', getMonthsBetweenDates(startDate, endDate));
            setDashboardData({
                labels: getMonthsBetweenDates(startDate, endDate),
                datasets: [{
                    label: dashboardData.label,
                    data: dashboardData.data.map((val) => val.count),
                    backgroundColor: 'white',
                }]
            });

        }
    }

    useEffect(() => {
        fetchDashboardData()
    }, [])
    return (
        <Box>
            <Box className={classes.dashboardWrapper}>
                <Bar options={options} data={dashboardData} />
            </Box>

            <Box className={classes.filterWrapper}>
                <Box className={classes.filter}>
                    <h3 > Filter Dashboard</h3>

                    <Group position="center" mb="xl">

                        <MonthPickerInput
                            type="range"
                            label="Pick Month range"
                            placeholder="Pick Month range"
                            value={dateRange} onChange={setDateRange}
                            mx="auto"
                            miw="300px"

                        />
                    </Group>

                    <Radio.Group
                        className={classes.radioStatus}
                        value={status}
                        onChange={setStatus}
                        name="status"
                        label="Select Status"
                        description="Select connection status"
                    >
                        <Group mt="xs" position='center'>
                            <Radio value="Approved" label="Approved" />
                            <Radio value="Pending" label="Pending" />
                            <Radio value="Connection Released" label="Connection Released" />
                            <Radio value="Rejected" label="Rejected" />
                        </Group>
                    </Radio.Group>
                    {/* </Group> */}
                    {error && <Box className={classes.error}> {error}</Box>}
                    <Button onClick={() => { fetchDashboardData() }} color='primary.0' radius="xl" size="md" mt="xl"> Apply</Button>
                </Box>
            </Box>
        </Box>
    );
}

export default ConnectionChart;